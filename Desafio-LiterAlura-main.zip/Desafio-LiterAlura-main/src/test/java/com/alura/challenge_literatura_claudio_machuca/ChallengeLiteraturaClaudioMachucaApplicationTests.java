package com.alura.challenge_literatura_claudio_machuca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeLiteraturaClaudioMachucaApplicationTests {

	@Test
	void contextLoads() {
	}

}
